# iron-cookie
[![Build Status](https://travis-ci.org/wincinderith/iron-cookie.svg?branch=master)](https://travis-ci.org/wincinderith/iron-cookie)

Polymer element for managing cookies. Read the docs [here](https://wincinderith.github.io/iron-cookie).
